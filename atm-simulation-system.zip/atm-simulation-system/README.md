# ATM Simulation System (C)

A console-based ATM simulation written in C. It lets a user log in with a PIN and perform common ATM operations.

## Features

- PIN login with 3 attempts (card is blocked after 3 wrong tries)
- **Balance enquiry**
- **Cash withdrawal** (multiples of 100, per-transaction limit, insufficient balance check)
- **Cash deposit**
- **PIN change** (verifies the current PIN and asks for confirmation)
- Input validation for letters, negative numbers and wrong menu choices

## C Concepts Used

Switch Case, Loops (`do-while`, `for`), Functions, Pointers (pass by reference), Strings

## Build & Run

```
make
./atm
```

Or without make:

```
gcc -Wall -o atm atm.c
./atm
```

On Windows (MinGW): `gcc atm.c -o atm.exe` then `atm.exe`

**Demo PIN:** `1234`  |  **Starting balance:** Rs. 10000

## Sample Flow

1. Enter PIN `1234`
2. Choose `1` to check balance
3. Choose `3` to deposit, `2` to withdraw
4. Choose `4` to change PIN, `5` to exit

## Project Structure

```
atm-simulation-system/
├── atm.c
├── Makefile
├── README.md
├── .gitignore
└── .github/workflows/build.yml   # CI: builds on every push
```
